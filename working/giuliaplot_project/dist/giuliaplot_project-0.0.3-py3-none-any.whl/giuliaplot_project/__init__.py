from .decorator import myplot
